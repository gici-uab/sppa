
%-------------------------------------------------------------------------%
% naoufal amrani,  Group on Interactive Coding of Images
% webpage: www.gici.uab.es
% email: naoufal.amrani@deic.uab.cat
%-------------------------------------------------------------------------%


function [im] = G_inv_PPA1D(Pim,U1,W,order,k,med)





[im] = G_inv_project_PPA(Pim,U1,W,order,k,med);



end
